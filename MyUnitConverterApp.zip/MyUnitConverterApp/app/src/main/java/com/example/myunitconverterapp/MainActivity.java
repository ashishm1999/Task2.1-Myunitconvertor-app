
package com.example.myunitconverterapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    ImageButton length;
    ImageButton weight;
    ImageButton temp;
    TextView V1;
    TextView V2;
    TextView V3;
    float number, value1, value2, value3;
    EditText operand1EditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Spinner spinner = findViewById(R.id.spinner1);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.numbers, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        length = findViewById(R.id.length);
        weight = findViewById(R.id.weight);
        temp = findViewById(R.id.temp);
        V1 = findViewById(R.id.V1);
        V2 = findViewById(R.id.V2);
        V3 = findViewById(R.id.V3);
        operand1EditText = findViewById(R.id.operand1EditText);

        length.setOnClickListener(new View.OnClickListener() {
            @ Override
            public void onClick(View v) {
                if (spinner.getSelectedItem().toString().equals("Metre"))
                {Double result=Double.parseDouble(operand1EditText.getText().toString()) * 100;
                    V1.setText(String.format("%.2f", result).trim() + "   centimeter");
                    Double result2=Double.parseDouble(operand1EditText.getText().toString()) * 39.37;
                    V2.setText(String.format("%.2f", result2).trim() + "   inches");
                    Double result3=Double.parseDouble(operand1EditText.getText().toString()) * 3.281;
                    V3.setText(String.format("%.2f", result3).trim() + "   foot");
                }
                else
                {
                    Toast.makeText( MainActivity.this ,  "Please select the correct conversion icon",Toast.LENGTH_LONG).show();
                }
            }
        });



        temp.setOnClickListener(new View.OnClickListener() {
            @ Override
            public void onClick(View v) {
                if (spinner.getSelectedItem().toString().equals("Celsius"))
                {Double result4=Double.parseDouble(operand1EditText.getText().toString()) + 273.15;
                    V1.setText(String.format(
                            "%.2f", result4).trim() + "   K");
                    Double result5=(Double.parseDouble(operand1EditText.getText().toString()) * 9 / 5) + 32;
                    V2.setText(String.format(
                            "%.2f", result5).trim() + "   Farenheit");
                    V3.setText("");
                }
                else
                {
                    Toast.makeText( MainActivity.this ,  "Please select the correct conversion icon",Toast.LENGTH_LONG).show();
                }
            }
        });

        weight.setOnClickListener(new View.OnClickListener() {
            @ Override
            public void onClick(View v) {
                if (spinner.getSelectedItem().toString().equals("kilograms"))
                {Double result6=Double.parseDouble(operand1EditText.getText().toString()) * 1000;
                    V1.setText(String.format(
                            "%.2f", result6).trim() + "   Gram");
                    Double result7=Double.parseDouble(operand1EditText.getText().toString()) * 35.274;
                    V2.setText(String.format(
                            "%.2f", result7).trim() + "   Ounce(Oz)");
                    Double result8=Double.parseDouble(operand1EditText.getText().toString()) * 2.205;
                    V3.setText(String.format(
                            "%.2f", result8).trim() + "  Pound");
                }
                else
                {
                    Toast.makeText( MainActivity.this ,  "Please select the correct conversion icon",Toast.LENGTH_LONG).show();
                }
            }
        });

    }
}

